source(output(
		country as string,
		country_code as string,
		continent as string,
		population as integer,
		indicator as string,
		daily_count as integer,
		date as date,
		rate_14_day as double,
		source as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> CasesandDeathsSource
source(output(
		country as string,
		country_code_2_digit as string,
		country_code_3_digit as string,
		continent as string,
		population as integer
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> countrylookup
CasesandDeathsSource filter(continent=="Europe" && not(isNull(country_code))) ~> FilterEuropeOnly
FilterEuropeOnly select(mapColumn(
		country,
		country_code,
		population,
		indicator,
		daily_count,
		source,
		each(match(name=="date"),
			'reported'+'_date' = $$)
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> SelectRequiredColumns
SelectRequiredColumns pivot(groupBy(country,
		country_code,
		population,
		source,
		reported_date),
	pivotBy(indicator, ['confirmed cases', 'deaths']),
	count = sum(daily_count),
	columnNaming: '$V_$N',
	lateral: true) ~> PivotCounts
PivotCounts, countrylookup lookup(PivotCounts@country == countrylookup@country,
	multiple: false,
	pickup: 'any',
	broadcast: 'auto')~> lookupcountry
lookupcountry select(mapColumn(
		country = PivotCounts@country,
		country_code_2_digit,
		country_code_3_digit,
		population = PivotCounts@population,
		cases_count = {confirmed cases_count},
		deaths_count,
		reported_date,
		source
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> SelectforSink
SelectforSink sink(allowSchemaDrift: true,
	validateSchema: false,
	truncate: true,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> CasesandDeathsSink