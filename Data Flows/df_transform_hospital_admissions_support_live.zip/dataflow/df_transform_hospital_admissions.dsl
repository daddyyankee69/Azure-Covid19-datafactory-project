source(output(
		country as string,
		indicator as string,
		date as date,
		year_week as string,
		value as double,
		source as string,
		url as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> hospitaladmissionSource
source(output(
		country as string,
		country_code_2_digit as string,
		country_code_3_digit as string,
		continent as string,
		population as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> CountryLookup
source(output(
		date_key as string,
		date as string,
		year as string,
		month as string,
		day as string,
		day_name as string,
		day_of_year as string,
		week_of_month as string,
		week_of_year as string,
		month_name as string,
		year_month as string,
		year_week as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> DimDateSource
hospitaladmissionSource select(mapColumn(
		country,
		indicator,
		reported_date = date,
		reported_year_week = year_week,
		value,
		source
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> selectrequirefcolumns
selectrequirefcolumns, CountryLookup lookup(selectrequirefcolumns@country == CountryLookup@country,
	multiple: false,
	pickup: 'any',
	broadcast: 'auto')~> lookupcountry
lookupcountry select(mapColumn(
		country = selectrequirefcolumns@country,
		indicator,
		reported_date,
		reported_year_week,
		value,
		source,
		country_code_2_digit,
		country_code_3_digit,
		population
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> selectreqcolumns
DimDateSource aggregate(groupBy(ecdc_year_week = year+'-W'+lpad(week_of_year,2,'0')),
	week_start_date = min(date),
		week_end_date = max(date)) ~> Aggdimdate
SplitDailyandWeekly@Weekly, Aggdimdate join(reported_year_week == ecdc_year_week,
	joinType:'inner',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> joinWithDate
joinWithDate pivot(groupBy(country,
		population,
		reported_year_week,
		week_start_date,
		week_end_date,
		source,
		country_code_2_digit,
		country_code_3_digit),
	pivotBy(indicator, ['Weekly new hospital admissions per 100k', 'Weekly new ICU admissions per 100k']),
	count = sum(value),
	columnNaming: '$V_$N',
	lateral: true) ~> PivotWeekly
selectreqcolumns split(indicator == 'Weekly new hospital admissions per 100k' || indicator == 'Weekly new ICU admissions per 100k',
	disjoint: false) ~> SplitDailyandWeekly@(Weekly, Daily)
SplitDailyandWeekly@Daily pivot(groupBy(country,
		population,
		country_code_2_digit,
		country_code_3_digit,
		reported_date,
		source),
	pivotBy(indicator, ['Daily ICU occupancy', 'Daily hospital occupancy']),
	count = sum(value),
	columnNaming: '$V_$N',
	lateral: true) ~> PivotDaily
PivotWeekly sort(asc(country, true),
	desc(reported_year_week, true)) ~> SortWeekly
PivotDaily sort(asc(country, true),
	desc(reported_date, true)) ~> SortDaily
SortWeekly select(mapColumn(
		country,
		country_code_2_digit,
		country_code_3_digit,
		population,
		reported_year_week,
		reported_week_start_date = week_start_date,
		reported_week_end_date = week_end_date,
		new_hospital_occupancy_count = {Weekly new hospital admissions per 100k_count},
		new_icu_occupancy_count = {Weekly new ICU admissions per 100k_count},
		source
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> selectWeekly
SortDaily select(mapColumn(
		country,
		country_code_2_digit,
		country_code_3_digit,
		population,
		reported_date,
		hospital_occupancy_count = {Daily hospital occupancy_count},
		icu_occupancy_count = {Daily ICU occupancy_count},
		source
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> selectDaily
selectWeekly sink(allowSchemaDrift: true,
	validateSchema: false,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> WeeklySink
selectDaily sink(allowSchemaDrift: true,
	validateSchema: false,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> DailySink